// Current usernames and passwords.
// Used for testing the system. 
// username accounts for testing different roles.

User: UserTest
Password: TestPassword
Role:DIGM

User: UserTest2
Password: AnotherTestPassword
Role:Coordinator

User: UserTest3
Password: AnotherPassword
Role:Senior

User: UserTest4
Password: AnotherTest
Role:DIGL

User: UserTest5
Password: PasswordTest
Role:DIGM

User: UserTest6
Password: AnotherPasswordTest
Role:Member

// What needs doing
//
// Some things might still be needed to be added to GUIs
//
// If any class specific actions don't work as intended, either attempt to fix it or wait and tell me it doesn't work and I will fix it
//
// data capture for DIGMs, 
