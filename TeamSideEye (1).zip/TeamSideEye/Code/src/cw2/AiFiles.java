/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class AiFiles {
    
    private static File file;
    private static ArrayList<File> files = new ArrayList<File>();
    
    /**
     * gets the files arraylist
     * @return 
     */
    public static ArrayList getFiles(){
        return files;
    }
    
    /**
     * creates a file with the entered name
     * @param name 
     */
    public static void createFile(String name){
        file = new File(name);
        try {
            file.createNewFile();
        } catch (IOException ex) {
            System.getLogger(AiFiles.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        files.add(file);
    }
}
