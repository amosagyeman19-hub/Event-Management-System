/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.Serializable;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class ActivityRecord implements Serializable{
    //eg audio, image, video, web record
    private String type;
    //id shared with the activity
    private String id;
    // a label given by a DIG of the activity
    private String label;
    // total estimate of people at the activty
    private int peopleAttended;
    // estimate of croud engagement
    private String engagement;
    // url of scrapped web source
    private String webSource;
    
    /**
     * constructor for the ActivityRecord class
     * @param recordType
     * @param recordId 
     */
    public ActivityRecord(String recordType, String recordId){
        type = recordType;
        id = recordId;
        label = "No label added";
        peopleAttended = 0;
        engagement = "LOW";
        webSource = "No web source added";
    }
    
    /**
     * adds a label to the current record
     * @param input 
     */
    public void addLabel(String input){
        label = input;
    }
    
    /**
     * adds the amount of people who attended the activity to the record
     * @param x 
     */
    public void headCount(int x){
        peopleAttended = x;
    }
    
    /**
     * adds the crowd engagement of people who attended the activity to the record
     * @param x 
     */
    public void crowdEngagement(String x){
        engagement = x;
    }
    
    /**
     * method to get the records id
     * @return 
     */
    public String getId(){
        return id;
    }
    
    /**
     * method to get the records type
     * @return 
     */
    public String getType(){
        return type;
    }
    
    /**
     * method to get the records label
     * @return 
     */
    public String getLabel(){
        return label;
    }
    
    /**
     * method to get the records attendance
     * @return 
     */
    public int getAttendance(){
        return peopleAttended;
    }
    
    /**
     * method to get the records engagement
     * @return 
     */
    public String getEngagement(){
        return engagement;
    }
    
    /**
     * method to get the records scrapped url
     * @return 
     */
    public String getURL(){
        return webSource;
    }
    
    /**
     * sets the entered url to be the web source
     * @param url 
     */
    public void addSource(String url){
        webSource = url;
    }
}
