/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;
import java.io.Serializable;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class DIGM extends Member implements Serializable{
    
    private Activity assignedActivity;
    private DIGL leader;
    
    /**
     * Constructor for the DIGM class
     * @param x
     * @param y
     * @param z 
     * @param h
     * @param i
     * @param j
     */
    public DIGM(String x, String y, String z, String h, String i, String j) {
        super(x, y, z, h, i, j);
    }
    
    /**
     * assigns this DIGM to an activity
     * @param x 
     */
    public void assignActivity(Activity x){
        assignedActivity = x;
        addToActivity();
    }
    
    /**
     * adds this digm to the activity digms array
     */
    private void addToActivity(){
        assignedActivity.assignDIGM(this);
    }
    
    /**
     * add a label to the record of the assigned activity
     * @param input
     */
    public void labelData(String input){
        assignedActivity.getRecord().addLabel(input); 
    }
    
    /**
     * updates the crowd attendance in the record of the assigned activity
     * @param input
     */
    public void updateAttendance(int input){
        assignedActivity.getRecord().headCount(input);
    }
    
    /**
     * updates the crowd engagement in the record of the assigned activity
     * @param input
     */
    public void updateEngagement(String input){
        assignedActivity.getRecord().crowdEngagement(input);
    }
    
    /**
     * sets the DIGMs leader to be the given DIGL object
     * @param x 
     */
    public void setLeader(DIGL x){
        leader = x;
    }
    
    /**
     * returns the DIGMs DIGL object
     * @return 
     */
    public DIGL getLeader(){
        return leader;
    }
    
    /**
     * returns the DIGMs currently assigned activity object
     * @return 
     */
    public Activity getActivity(){
        return assignedActivity;
    }
    
    /**
     * adds a web scraped URL to the record of the assigned activity
     *
     * @param url
     */
    public void addWebSource(String url) {
        assignedActivity.getRecord().addSource(url);
    }
}
