/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class Activities implements Serializable{
    // an array of all activities including open and cancelled
    private static ArrayList<Activity> activities = new ArrayList<Activity>();
    // an array of all activity records
    private static ArrayList<ActivityRecord> records = new ArrayList<ActivityRecord>();
    
    /**
     * adds a new activity to the activities array
     * @param x 
     */
    public static void addActivity(Activity x){
        activities.add(x);
    }
    
    /**
     * adds a new activity record to the records array
     * @param x 
     */
    public static void addRecord(ActivityRecord x){
        records.add(x);
    }
    
    /**
     * gets an activity from the activities array with the same id as the entered id
     * @param id
     * @return 
     */
    public static Activity getActivity(String id){
        Activity objToSend = null;
        for (int i = 0; i < activities.size(); i++){
            if(activities.get(i).getId().equals(id)){
                objToSend = activities.get(i);
            }
        }
        return objToSend;
    }
    
    public static ArrayList<Activity> getAllOpenActivities() {
        ArrayList<Activity> open = new ArrayList<>();
        for (int i = 0; i < activities.size(); i++) {
            if (activities.get(i).getStatus().equals("Open")) {
                open.add(activities.get(i));
            }
        }
        return open;
    }
    
    /**
     * gets an activity record from the records array with the same id as the entered id
     * @param id
     * @return 
     */
    public static ActivityRecord getRecord(String id){
        ActivityRecord objToSend = null;
        for (int i = 0; i < records.size(); i++){
            if(records.get(i).getId().equals(id)){
                objToSend = records.get(i);
            }
        }
        return objToSend;
    }
    
    
    public static Activity getActivityFromName(String name){
        Activity objToSend = null;
        for (int i = 0; i < activities.size(); i++){
            if(activities.get(i).getName().equals(name)){
                objToSend = activities.get(i);
            }
        }
        return objToSend;
    }
    
    public static void writeObjects() {
        try {
            java.io.ObjectOutputStream out = new java.io.ObjectOutputStream(
                    new java.io.FileOutputStream("Activities.ser"));
            out.writeObject(activities);
            out.writeObject(records);
            out.close();
        } catch (java.io.IOException e) {
            System.out.println("Error saving activities");
        }
    }

    public static void readObjects() {
        try {
            java.io.ObjectInputStream in = new java.io.ObjectInputStream(
                    new java.io.FileInputStream("Activities.ser"));
            activities = (ArrayList<Activity>) in.readObject();
            records = (ArrayList<ActivityRecord>) in.readObject();
            in.close();
            System.out.println("Activities loaded: " + activities.size());
        } catch (Exception e) {
            System.out.println("No saved activities found");
        }

    }
}
