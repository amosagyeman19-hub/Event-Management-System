/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class User {
    
    /**
     * takes the users role and username, and sets the relevant current user object to be the object the same type as the role, with the same username
     * @param role
     * @param username 
     */
    public static void setUser(String role, String username){
        switch(role){
            case "Member":
                BD25System.userMember = Users.findMember(username);
                BD25System.userSenior = null;
                BD25System.userDIGL = null;
                BD25System.userDIGM = null;
                BD25System.userCoordinator = null;
                BD25System.currentUserType = role;
                break;
            case "Senior":
                BD25System.userMember = null;
                BD25System.userSenior = Users.findSenior(username);
                BD25System.userDIGL = null;
                BD25System.userDIGM = null;
                BD25System.userCoordinator = null;
                BD25System.currentUserType = role;
                break;
            case "DIGL":
                BD25System.userMember = null;
                BD25System.userSenior = null;
                BD25System.userDIGL = Users.findDIGL(username);
                BD25System.userDIGM = null;
                BD25System.userCoordinator = null;
                BD25System.currentUserType = role;
                break;
            case "DIGM":
                BD25System.userMember = null;
                BD25System.userSenior = null;
                BD25System.userDIGL = null;
                BD25System.userDIGM = Users.findDIGM(username);
                BD25System.userCoordinator = null;
                BD25System.currentUserType = role;
                break;
            case "Coordinator":
                BD25System.userMember = null;
                BD25System.userSenior = null;
                BD25System.userDIGL = null;
                BD25System.userDIGM = null;
                BD25System.userCoordinator = Users.findCoordinator(username);
                BD25System.currentUserType = role;
                break;
        }
    }

}
