/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cw2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class BD25System implements Serializable{

    /**
     * @param args the command line arguments
     */
    
    //The type of the current user
    public static String currentUserType;
    //The user object if the user is a member
    public static Member userMember;
    //The user object if the user is a senior member
    public static SeniorMember userSenior;
    //The user object if the user is a DIGL
    public static DIGL userDIGL;
    //The user object if the user is a DIGM
    public static DIGM userDIGM;
    //The user object if the user is a activity coordinator
    public static ActivityCoordinator userCoordinator;

    
    static GUI gui;
    
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException, FileNotFoundException, ClassNotFoundException {
        UserCreator creator = new UserCreator();

        Users.readObjects();
        Users.writeToFileWriter();
        Users.writeObjects();
        
        Activities.readObjects();
        Activities.writeObjects();
        
        // creates the gui object and opens the login screen
        gui = new GUI();
        reloadPage("login");
    }
    
    /**
     * Opens the next required screen
     * @param screen 
     */
    public static void reloadPage(String screen){
        
        switch(screen){
            case "home":
                new HomeScreenGUI().setVisible(true);
                break;
            default:
                gui.loginScreen();
                break;
        }
    }

}
