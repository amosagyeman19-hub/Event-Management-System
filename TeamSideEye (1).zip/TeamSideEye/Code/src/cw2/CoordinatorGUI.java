/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class CoordinatorGUI implements ActionListener{
    
    // the frame for the gui
    private JFrame frame;
    // the panel which is on the frame
    private JPanel panel;
    // the text field for activity name
    private JTextField textName;
    // the text field for activity date
    private JTextField textDate;
    // the text field for activity location
    private JTextField textLocation;
    // the text field for activity id
    private JTextField textId;
    // the text field to enter record type
    private JTextField textType;
    // the button to submit the activity
    private JButton submitCreation;
    // the button to update an activity
    private JButton submitUpdate;
    // the button to submit the cancellation
    private JButton submitCancel;
    // a label which syas the input data is invalid
    private JLabel errorLabel;
    // a label which says the record type is invalid
    private JLabel badType;
    // a label which says the date format was wrong
    private JLabel badDate;
    // a class field for activity
    private Activity currentActivity;
    
    /**
     * the gui for the activity creation, for activity coordinators
     */
    public void createActivity(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,350);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Create new activity");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter activity name");
        label.setBounds(10, 20 ,150, 25);
        panel.add(label);
        
        textName = new JTextField(20);
        textName.setBounds(10, 50, 300, 25);
        panel.add(textName);
        
        JLabel label2 = new JLabel("Enter activity date");
        label2.setBounds(10, 80 ,150, 25);
        panel.add(label2);
        
        badDate = new JLabel("Date must be in format dd/mm/yyyy");
        badDate.setBounds(120, 110, 200, 25);
        badDate.setForeground(Color.red);
        panel.add(badDate);
        badDate.setVisible(false);
        
        textDate = new JTextField(20);
        textDate.setBounds(10, 140, 300, 25);
        panel.add(textDate);
        
        JLabel label3 = new JLabel("Enter activity location");
        label3.setBounds(10, 170 ,150, 25);
        panel.add(label3);
        
        textLocation = new JTextField(20);
        textLocation.setBounds(10, 200, 300, 25);
        panel.add(textLocation);
        
        JLabel label4 = new JLabel("Enter activity record type");
        label4.setBounds(10, 230 ,150, 25);
        panel.add(label4);
        
        textType = new JTextField(20);
        textType.setBounds(10, 260, 300, 25);
        panel.add(textType);
        
        badType = new JLabel("Must be of type audio, image, video, web record");
        badType.setBounds(120, 110, 200, 25);
        badType.setForeground(Color.red);
        panel.add(badType);
        badType.setVisible(false);
        
        submitCreation = new JButton("Submit");
        submitCreation.setBounds(10, 290, 80, 25);
        submitCreation.addActionListener(this);
        panel.add(submitCreation);
        
        frame.setVisible(true);
    }
    
    /**
     * the gui for updating an activity, for activity coordinators
     * @param activity 
     */
    public void updateActivity(Activity activity) {
        currentActivity = activity;
        panel = new JPanel();
        frame = new JFrame();
        frame.setSize(350, 300);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Update Activity");
        frame.add(panel);
        panel.setLayout(null);

        JLabel label = new JLabel("Enter new name");
        label.setBounds(10, 20, 150, 25);
        panel.add(label);

        textName = new JTextField(20);
        textName.setBounds(10, 50, 300, 25);
        panel.add(textName);

        JLabel label2 = new JLabel("Enter new date");
        label2.setBounds(10, 80, 150, 25);
        panel.add(label2);

        textDate = new JTextField(20);
        textDate.setBounds(10, 110, 300, 25);
        panel.add(textDate);

        JLabel label3 = new JLabel("Enter new location");
        label3.setBounds(10, 140, 150, 25);
        panel.add(label3);

        textLocation = new JTextField(20);
        textLocation.setBounds(10, 170, 300, 25);
        panel.add(textLocation);

        submitUpdate = new JButton("Update");
        submitUpdate.setBounds(10, 210, 80, 25);
        submitUpdate.addActionListener(this);
        panel.add(submitUpdate);

        frame.setVisible(true);
        
    }
    /**
     * the gui for activity cancellation for activity coordinators
     */
    public void cancelActivity(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,300);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Cancel activity");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter activity ID");
        label.setBounds(10, 20 ,150, 25);
        panel.add(label);
        
        textId = new JTextField(20);
        textId.setBounds(10, 50, 300, 25);
        panel.add(textId);
        
        errorLabel = new JLabel("Entered value is not a valid ID");
        errorLabel.setBounds(10, 80, 250, 25);
        errorLabel.setForeground(Color.red);
        panel.add(errorLabel);
        errorLabel.setVisible(false);
        
        submitCancel = new JButton("Submit");
        submitCancel.setBounds(10, 170, 80, 25);
        submitCancel.addActionListener(this);
        panel.add(submitCancel);
        
        frame.setVisible(true);
    }
    
    /**
     * when the correct button is pressed, the first will add then new activity after checking input data, second will cancel activity if correct activity id was given
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == submitCreation){
            boolean typeCorrect = false;
            String name = textName.getText();
            String date = textDate.getText();
            String location = textLocation.getText();
            String type = textType.getText().toLowerCase();
            String id = UserCreator.idMaker("Activity");
            while (Users.isUniqueId(id) == false){
                id = UserCreator.idMaker("Activity");
            }
            if(type.equals("image") || type.equals("audio") || type.equals("video") || type.equals("web record")){
                typeCorrect = true;
            }
            else{
                badType.setVisible(true);
            }
            
            if(name != null && date != null && location != null && Activity.checkDate(date) == true && typeCorrect == true){
                BD25System.userCoordinator.createActivity(name, date, location, id, type);
                Activities.writeObjects();
                frame.dispose();
            }
            
            if(Activity.checkDate(date) == false){
                badDate.setVisible(true);
            }
            else if(Activity.checkDate(date) == true){
                badDate.setVisible(false);
            }
        }
        
        else if(e.getSource() == submitCancel){
            String id = textId.getText();
            ArrayList<Activity> activities= BD25System.userCoordinator.getOpenActivities();
            for(int i = 0; i < activities.size(); i++){
                if(activities.get(i).getId().equals(id)){
                    BD25System.userCoordinator.cancelActivity(activities.get(i));
                    frame.dispose();
                }
            }
            errorLabel.setVisible(true);
        }
        
        else if (e.getSource() == submitUpdate) {
            currentActivity.setName(textName.getText());
            currentActivity.setDate(textDate.getText());
            currentActivity.setLocation(textLocation.getText());
            Activities.writeObjects();
            frame.dispose();
            System.out.println("Current activity: " + currentActivity);
            System.out.println("New name: " + textName.getText());
        }
    }
}
