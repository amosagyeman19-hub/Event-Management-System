/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.Serializable;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class Member implements Serializable{
    // name of the member
    private String name;
    // member's username
    private String username;
    // member's standard formal role
    private String role;
    // member's id number, can include letters
    private String id;
    
    private String salt;
    
    private String password;
    
    /**
     * Constructor for the member class
     * @param x
     * @param y
     * @param z 
     * @param h
     * @param i
     * @param j
     */
    public Member(String x, String y, String z, String h, String i, String j){
        name = x;
        role = y;
        id = z;
        username = h;
        salt = i;
        password = j;
    }
    
    /**
     * returns the member's name
     * @return 
     */
    public String getName(){
        return name;
    }
    
    /**
     * returns the member's role
     * @return 
     */
    public String getRole(){
        return role;
    }
    
    /**
     * returns the member's id
     * @return 
     */
    public String getId(){
        return id;
    }
    
    /**
     * returns the member's username
     * @return 
     */
    public String getUsername(){
        return username;
    }
    
    /**
     * returns the member's salt
     * @return 
     */
    public String getSalt(){
        return salt;
    }
    
    /**
     * returns the member's password
     * @return 
     */
    public String getPass(){
        return password;
    }
    
    /**
     * sets member's name
     * @param x 
     */
    public void setName(String x){
        name = x;
    }
    
    /**
     * sets member's role
     * @param x 
     */
    public void setRole(String x){
        role = x;
    }
    
    /**
     * sets member's id number
     * @param x 
     */
    public void setId(String x){
        id = x;
    }
    
    
    public void setUsername(String x){
        username = x;
    }
}
