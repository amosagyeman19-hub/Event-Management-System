/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class Searcher {

// is true when the current block of user data belongs to the username entered
private static boolean onCurrentUser;
// the salt requested
private static String salt;
// the password requested
private static String password;
// the role requested
private static String role;
// the file containing user data
static File file = new File("Users.txt");
    
    /**
     * searches through the users file for the users salt
     * @param username
     * @return 
     */
    public static String saltFinder(String username){
        
        Scanner searcher = null;
    try {
        searcher = new Scanner(file);
    } catch (FileNotFoundException ex) {
        System.getLogger(Searcher.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }
        
        while (searcher.hasNextLine()) {
            String line = searcher.nextLine();
            
            if (line.length() > 5 && line.substring(0, 5).equals("User:") && line.substring(5).equals(username)) {
                onCurrentUser = true;
            } else if (line.length() > 5 && line.substring(0, 5).equals("User:") && line.substring(5) != username) {
                onCurrentUser = false;
            }

            if (line.length() > 5 && line.substring(0, 5).equals("Salt:") && onCurrentUser == true) {
                salt = line.substring(5);
            }
        }
        
        if(salt == null){
            System.out.println("Salt not found");
            salt = "Error";
        }
        return salt;
    }
    
    /**
     * Searches through the users file for the users hashed password
     * @param username
     * @return 
     */
    public static String passFinder(String username){
        
        Scanner searcher = null;
    try {
        searcher = new Scanner(file);
    } catch (FileNotFoundException ex) {
        System.getLogger(Searcher.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }
        
        while (searcher.hasNextLine()) {
            String line = searcher.nextLine();
            
            if (line.length() > 5 && line.substring(0, 5).equals("User:") && line.substring(5).equals(username)) {
                onCurrentUser = true;
            } else if (line.length() > 5 && line.substring(0, 5).equals("User:") && line.substring(5) != username) {
                onCurrentUser = false;
            }

            if (line.length() > 5 && line.substring(0, 5).equals("Pass:") && onCurrentUser == true) {
                password = line.substring(5);
            }
        }
        
        if(password == null){
            System.out.println("Password not found");
            password = "Error";
        }
        return password;
    }
    
    /**
     * Searches through the users file for the users role
     * @param username
     * @return 
     */
    public static String roleFinder(String username){
        
        Scanner searcher = null;
    try {
        searcher = new Scanner(file);
    } catch (FileNotFoundException ex) {
        System.getLogger(Searcher.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
    }
        
        while (searcher.hasNextLine()) {
            String line = searcher.nextLine();
            
            if (line.length() > 5 && line.substring(0, 5).equals("User:") && line.substring(5).equals(username)) {
                onCurrentUser = true;
            } else if (line.length() > 5 && line.substring(0, 5).equals("User:") && line.substring(5) != username) {
                onCurrentUser = false;
            }

            if (line.length() > 5 && line.substring(0, 5).equals("Role:") && onCurrentUser == true) {
                role = line.substring(5);
            }
        }
        
        if(role == null){
            System.out.println("Role not found");
            role = "Error";
        }
        return role;
    }
}
