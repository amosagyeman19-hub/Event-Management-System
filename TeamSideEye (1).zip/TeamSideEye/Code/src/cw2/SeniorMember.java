/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.Serializable;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class SeniorMember extends Member implements Serializable{
    
    /**
     * Constructor for the SeniorMember class
     * @param x
     * @param y
     * @param z 
     * @param h
     * @param i
     * @param j
     */
    public SeniorMember(String x, String y, String z, String h, String i, String j) {
        super(x, y, z, h, i, j);
    }
    
}