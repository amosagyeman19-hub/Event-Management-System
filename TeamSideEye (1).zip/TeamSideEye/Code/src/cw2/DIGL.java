/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;
import java.io.Serializable;
import java.util.ArrayList;
/**
 *
 * @author George Hartley   UB:25010763
 */
public class DIGL extends DIGM implements Serializable{
    
    private Activity assignedActivity;
    // an array containng the DIGMs in the DIG group
    private ArrayList<DIGM> group = new ArrayList<DIGM>();
    
    /**
     * Constructor for the DIGL class
     * @param x
     * @param y
     * @param z 
     * @param h
     */
    public DIGL(String x, String y, String z, String h, String i, String j) {
        super(x, y, z, h, i, j);
    }
    
    /**
     * Adds a new member to the DIG group
     * @param x 
     */
    public void addMember(DIGM x){
        group.add(x);
        x.setLeader(this);
        if(group.size() < 2){
            System.out.println("DIG group needs atleast 3 members");
        }
    }
    
    /**
     * returns the group array
     * @return 
     */
    public ArrayList getGroup(){
        return group;
    }
    
    /**
     * changes this digls assigned activity
     * @param x 
     */
    @Override
    public void assignActivity(Activity x){
        assignedActivity = x;
        addToActivity();
    }
    
    /**
     * adds this digl to the activities digl reference
     */
    private void addToActivity(){
        assignedActivity.assignDIGL(this);
    }
}
