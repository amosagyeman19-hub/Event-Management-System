/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class Activity implements Serializable{
    // name of the activity
    private String name;
    // date of the activity, date must have format dd/mm/yyyy
    private String date;
    // location of the activity
    private String location;
    // activity's id number, can include letters, (!ID's should be unique!)
    private String id;
    // the DIGL assigned to this activity
    private DIGL digl;
    // tracks if the actvity is still open or cancelled
    private Boolean cancelled;
    // an array of all DIGMs assigned to this activity
    private ArrayList<DIGM> digms = new ArrayList<DIGM>();
    // a record of the activity
    private ActivityRecord record;
    
    /**
     * Constructor for the activity class
     * @param w
     * @param x
     * @param y
     * @param z 
     */
    public Activity(String w, String x, String y, String z){
        name = w;
        location = y;
        id = z;
        
        if(checkDate(x) == true){
            date = x;
        }
        else{
            date = "dd/mm/yyyy";
            System.out.println("Error: date in wrong format");
        }
        
        cancelled = false;
    }
    
    /**
     * returns the activity's name
     * @return 
     */
    public String getName(){
        return name;
    }
    
    /**
     * returns the activity's date
     * @return 
     */
    public String getDate(){
        return date;
    }
    
    /**
     * returns the activity's location
     * @return 
     */
    public String getLocation(){
        return location;
    }
    
    /**
     * returns the activity's id
     * @return 
     */
    public String getId(){
        return id;
    }
    
    /**
     * returns the activity's activity record
     * @return 
     */
    public ActivityRecord getRecord(){
        return record;
    }
    
    /**
     * sets activity's name
     * @param x 
     */
    public void setName(String x){
        name = x;
    }
    
    /**
     * sets activity's date
     * @param x 
     */
    public void setDate(String x){
        if(checkDate(x) == true){
            date = x;
        }
        else{
            date = "dd/mm/yyyy";
            System.out.println("Error: date in wrong format");
        }
    }
    
    /**
     * sets activity's location
     * @param x 
     */
    public void setLocation(String x){
        location = x;
    }
    
    /**
     * sets activity's id number
     * @param x 
     */
    public void setId(String x){
        id = x;
    }

    /**
     * checks if the date entered is valid, and returns true of false depending on validity
     * @param x
     * @return 
     */
    public static Boolean checkDate(String x){
        //(dd/mm/yyyy)
        if(x.substring(2,3).equals("/") && x.substring(5,6).equals("/") && x.length() == 10){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * Assign a DIGL to this activity
     * If a DIGl is already assigned this will overwrite current DIGL
     * @param x 
     */
    public void assignDIGL(DIGL x){
        digl = x;
    }
    
    /**
     * Assign a DIGM to this activity
     * @param x 
     */
    public void assignDIGM(DIGM x){
        digms.add(x);
    }
    
    /**
     * Will cancel the activity when called
     */
    public void cancelActivity(){
        cancelled = true;
    }
    
    /**
     * will return the digms arraylist
     * @return 
     */
    public ArrayList getDIGMs(){
        return digms;
    }
    
    /**
     * will return the current digl
     * @return 
     */
    public DIGL getDIGL(){
        return digl;
    }
    
    /**
     * will return the activities current status
     * @return 
     */
    public String getStatus(){
        if(cancelled == true){
            return "Cancelled";
        }
        else{
            return "Open";
        }
    }
    
    /**
     * creates the activity record for the current activity
     * @param recordType 
     */
    public void createRecord(String recordType){
        record = new ActivityRecord(recordType, id);
        Activities.addRecord(record);
    }
}
