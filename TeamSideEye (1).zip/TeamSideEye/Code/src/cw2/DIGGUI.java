/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class DIGGUI implements ActionListener{
    // the frame for the gui
    private JFrame frame;
    // the panel which is on the frame
    private JPanel panel;
    // a text field
    private JTextField text;
    // the button to submit the label
    private JButton submitLabel;
    // the button to submit the attendance
    private JButton submitAttendance;
    // the button to submit the engagement
    private JButton submitEngagement;
    // the button for submitting a new member
    private JButton submitMember;
    // the button to submit id for activity assigning
    private JButton submitId;
    // a label which syas the input data is unvalid
    private JLabel errorLabel;
    // the button to submit data source
    private JButton submitWebSource;

    /**
     * the gui for labelling data for DIGMs and DIGLs
     */
    public void labelData(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,250);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Data Labelling");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter label bellow");
        label.setBounds(10, 20 ,150, 25);
        panel.add(label);
        
        text = new JTextField(20);
        text.setBounds(10, 50, 300, 100);
        panel.add(text);
        
        submitLabel = new JButton("Submit");
        submitLabel.setBounds(10, 170, 80, 25);
        submitLabel.addActionListener(this);
        panel.add(submitLabel);
        
        frame.setVisible(true);
    }
    
    /**
     * the gui for updating attendance for DIGMs and DIGLs
     */
    public void updateAttendance(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,200);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Update Attendance");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter attendance bellow");
        label.setBounds(10, 20 ,150, 25);
        panel.add(label);
        
        text = new JTextField(20);
        text.setBounds(10, 80, 300, 25);
        panel.add(text);
        
        submitAttendance = new JButton("Submit");
        submitAttendance.setBounds(10, 110, 80, 25);
        submitAttendance.addActionListener(this);
        panel.add(submitAttendance);
        
        errorLabel = new JLabel("Entered value is not a number");
        errorLabel.setBounds(10, 50, 200, 25);
        errorLabel.setForeground(Color.red);
        panel.add(errorLabel);
        errorLabel.setVisible(false);
        
        frame.setVisible(true);
    }
    
    /**
     * the gui for updating crowd engagement for DIGMs and DIGLs
     */
    public void updateEngagement(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,200);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Update Engagement");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter crowd engagement bellow");
        label.setBounds(10, 20 ,200, 25);
        panel.add(label);
        
        text = new JTextField(20);
        text.setBounds(10, 80, 300, 25);
        panel.add(text);
        
        submitEngagement = new JButton("Submit");
        submitEngagement.setBounds(10, 110, 80, 25);
        submitEngagement.addActionListener(this);
        panel.add(submitEngagement);
        
        errorLabel = new JLabel("Entered value must be low/medium/high/very high");
        errorLabel.setBounds(10, 50, 300, 25);
        errorLabel.setForeground(Color.red);
        panel.add(errorLabel);
        errorLabel.setVisible(false);
        
        frame.setVisible(true);
    }
    
    /**
     * the gui for assign to an activity
     */
    public void assignActivity(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,200);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Assign activity");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter activity ID");
        label.setBounds(10, 20 ,150, 25);
        panel.add(label);
        
        text = new JTextField(20);
        text.setBounds(10, 50, 300, 25);
        panel.add(text);
        
        errorLabel = new JLabel("Entered value is not a valid ID");
        errorLabel.setBounds(10, 80, 250, 25);
        errorLabel.setForeground(Color.red);
        panel.add(errorLabel);
        errorLabel.setVisible(false);
        
        submitId = new JButton("Submit");
        submitId.setBounds(10, 110, 80, 25);
        submitId.addActionListener(this);
        panel.add(submitId);
        
        frame.setVisible(true);
    }
    
    /**
     * the gui for adding a new member to the dig group, for the DIGL
     */
    public void addNewMember(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350, 250);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Add new member");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel label = new JLabel("Enter id number of the DIG member");
        label.setBounds(10, 20 ,200, 25);
        panel.add(label);
        
        text = new JTextField(20);
        text.setBounds(10, 80, 300, 25);
        panel.add(text);
        
        submitMember = new JButton("Submit");
        submitMember.setBounds(10, 170, 80, 25);
        submitMember.addActionListener(this);
        panel.add(submitMember);
        
        errorLabel = new JLabel("Entered value is not a valid ID");
        errorLabel.setBounds(10, 140, 300, 25);
        errorLabel.setForeground(Color.red);
        panel.add(errorLabel);
        errorLabel.setVisible(false);
        
        frame.setVisible(true);
    }
    
    /**
     * the gui for adding a web source
    */
    public void addWebSource() {
        panel = new JPanel();

        frame = new JFrame();
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Add Web Source");

        frame.add(panel);
        panel.setLayout(null);

        JLabel label = new JLabel("Enter URL below");
        label.setBounds(10, 20, 150, 25);
        panel.add(label);

        text = new JTextField(20);
        text.setBounds(10, 80, 300, 25);
        panel.add(text);

        submitWebSource = new JButton("Submit");
        submitWebSource.setBounds(10, 110, 80, 25);
        submitWebSource.addActionListener(this);
        panel.add(submitWebSource);

        frame.setVisible(true);
    }
    
    /**
     * When the submit button is pressed the relevant DIG action is carried out
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == submitLabel){
            String label = text.getText();
            if(BD25System.currentUserType.equals("DIGM")){
                BD25System.userDIGM.labelData(label);
                frame.dispose();
            }
            else if(BD25System.currentUserType.equals("DIGL")){
                BD25System.userDIGL.labelData(label);
                frame.dispose();
            }
        }
        
        else if (e.getSource() == submitAttendance) {
            String attendance = text.getText();
            try {
                int att = Integer.parseInt(attendance);
                if (BD25System.currentUserType.equals("DIGM")) {
                    BD25System.userDIGM.updateAttendance(att);
                    frame.dispose();
                } 
                else if (BD25System.currentUserType.equals("DIGL")) {
                    BD25System.userDIGL.updateAttendance(att);
                    frame.dispose();
                }
            } catch (NumberFormatException f) {
                errorLabel.setVisible(true);
            }
        }
        
        else if (e.getSource() == submitEngagement) {
            String input = text.getText().toUpperCase();
            String[] allowedInputs = {"LOW", "MEDIUM", "HIGH", "VERY HIGH"};
            for (int i = 0; i < allowedInputs.length; i++) {
                if (allowedInputs[i].equals(input)) {
                    if (BD25System.currentUserType.equals("DIGM")) {
                        BD25System.userDIGM.updateEngagement(input);
                        frame.dispose();
                    } else if (BD25System.currentUserType.equals("DIGL")) {
                        BD25System.userDIGL.updateEngagement(input);
                        frame.dispose();
                    }
                }
            }
            errorLabel.setVisible(true);
        }
        
        else if (e.getSource() == submitId) {
            String id = text.getText();
            System.out.println("Looking for activity: " + id);
            System.out.println("Activity found: " + Activities.getActivity(id));
            if(Activities.getActivity(id) == null){
                errorLabel.setVisible(true);
            }
            else if (BD25System.currentUserType.equals("DIGM")) {
                BD25System.userDIGM.assignActivity(Activities.getActivity(id));
                frame.dispose();
            } else if (BD25System.currentUserType.equals("DIGL")) {
                BD25System.userDIGL.assignActivity(Activities.getActivity(id));
                frame.dispose();
            }

        }
        
        else if (e.getSource() == submitMember){
            String id = text.getText();
            DIGM digm = Users.DIGMFindId(id);
            if(digm == null){
                errorLabel.setVisible(true);
            }
            else{
                errorLabel.setVisible(false);
                BD25System.userDIGL.addMember(digm);
                if (BD25System.userDIGL.getGroup().size() < 3) {
                    errorLabel.setText("DIG needs at least " + (3 - BD25System.userDIGL.getGroup().size()) + " more member(s)");
                    errorLabel.setVisible(true);
                } else {
                    frame.dispose();
                }
            }
        }
        else if (e.getSource() == submitWebSource) {
            String url = text.getText();
            if (BD25System.currentUserType.equals("DIGM")) {
                BD25System.userDIGM.addWebSource(url);
                frame.dispose();
            }
        }
    }
}
