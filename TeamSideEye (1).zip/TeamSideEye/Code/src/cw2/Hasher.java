/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
/**
 *
 * @author George Hartley   UB:25010763
 */
public class Hasher {
    
    /**
     * Takes a string in plain text and returns the hashed string, uses the MD5 hashing algorithm
     * @param plainText
     * @return
     * @throws NoSuchAlgorithmException 
     */
    public static String hash(String plainText) throws NoSuchAlgorithmException{
        
        //available hashing algorithms MD2, MD5, SHA-1, SHA-224, SHA-256
        MessageDigest message = MessageDigest.getInstance("MD5");
        
        byte[] digest = message.digest(plainText.getBytes());
        
        BigInteger bigInt = new BigInteger(1,digest);
        
        String hash = bigInt.toString(16);
        return hash;
    }
    
    /**
     * Creates a new salt, generates a random number between 1 and 26 which is then turned into a letter from the alphabet
     * This is done 4 times, the result is turned into a string of 4 characters.
     * @return 
     */
    public static String saltMaker(){
        Random random = new Random();
        char[] array = new char[4];
        for(int i = 0; i < 4; i++){
            // generates a random from 1 to 26
            String rand = Integer.toString(random.nextInt(26) + 1);
            switch(rand){
                case "1":
                    array[i] = 'a';
                    break;
                case "2":
                    array[i] = 'b';
                    break;
                case "3":
                    array[i] = 'c';
                    break;
                case "4":
                    array[i] = 'd';
                    break;
                case "5":
                    array[i] = 'e';
                    break;
                case "6":
                    array[i] = 'f';
                    break;
                case "7":
                    array[i] = 'g';
                    break;
                case "8":
                    array[i] = 'h';
                    break;
                case "9":
                    array[i] = 'i';
                    break;
                case "10":
                    array[i] = 'j';
                    break;
                case "11":
                    array[i] = 'k';
                    break;
                case "12":
                    array[i] = 'l';
                    break;
                case "13":
                    array[i] = 'm';
                    break;
                case "14":
                    array[i] = 'n';
                    break;
                case "15":
                    array[i] = 'o';
                    break;
                case "16":
                    array[i] = 'p';
                    break;
                case "17":
                    array[i] = 'q';
                    break;
                case "18":
                    array[i] = 'r';
                    break;
                case "19":
                    array[i] = 's';
                    break;
                case "20":
                    array[i] = 't';
                    break;
                case "21":
                    array[i] = 'u';
                    break;
                case "22":
                    array[i] = 'v';
                    break;
                case "23":
                    array[i] = 'w';
                    break;
                case "24":
                    array[i] = 'x';
                    break;
                case "25":
                    array[i] = 'y';
                    break;
                case "26":
                    array[i] = 'z';
                    break;
            }
        }
        String salt = new String(array);
        return salt;
    }

}


