/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class UserCreator {
    
    private static File users;
    public static BufferedWriter writer;
    
    /**
     * Constructor for the UserCreator class
     * @throws IOException 
     */
    public UserCreator() throws IOException{
        users = new File("Users.txt");
        writer = new BufferedWriter(new FileWriter(users));
    }
    
    /**
     * creates a new member object, adds the object to the member list, adds the details to the users file
     * @param name
     * @param id
     * @param username
     * @param salt
     * @param pass
     * @throws NoSuchAlgorithmException 
     */
    public static void createMember(String name, String id, String username, String salt, String pass) throws NoSuchAlgorithmException, IOException{
        String password = Hasher.hash(pass+salt);
        Member member = new Member(name, "Member", id, username, salt, password);
        Users.addMember(member);
        Users.addUsername(username);
        fileWriter(username, name, "Member", id, salt, password);
        Users.writeObjects();
    }
    
    /**
     * creates a new senior member object, adds the object to the senior list, adds the details to the users file
     * @param name
     * @param id
     * @param username
     * @param salt
     * @param pass
     * @throws NoSuchAlgorithmException 
     */
    public static void createSenior(String name, String id, String username, String salt, String pass) throws NoSuchAlgorithmException, IOException{
        String password = Hasher.hash(pass+salt);
        SeniorMember senior = new SeniorMember(name, "Senior", id, username, salt, password);
        Users.addSenior(senior);
        Users.addUsername(username);
        fileWriter(username, name, "Senior", id, salt, password);
        Users.writeObjects();
    }
    
    /**
     * creates a new DIGM object, adds the object to the DIGM list, adds the details to the users file
     * @param name
     * @param id
     * @param username
     * @param salt
     * @param pass
     * @throws NoSuchAlgorithmException 
     */
    public static void createDIGM(String name, String id, String username, String salt, String pass) throws NoSuchAlgorithmException, IOException{
        String password = Hasher.hash(pass+salt);
        DIGM digm = new DIGM(name, "DIGM", id, username, salt, password);
        Users.addDIGM(digm);
        Users.addUsername(username);
        fileWriter(username, name, "DIGM", id, salt, password);
        Users.writeObjects();
    }
    
    /**
     * creates a new DIGL object, adds the object to the DIGL list, adds the details to the users file
     * @param name
     * @param id
     * @param username
     * @param salt
     * @param pass
     * @throws NoSuchAlgorithmException 
     */
    public static void createDIGL(String name, String id, String username, String salt, String pass) throws NoSuchAlgorithmException, IOException{
        String password = Hasher.hash(pass+salt);
        DIGL digl = new DIGL(name, "DIGL", id, username, salt, password);
        Users.addDIGL(digl);
        Users.addUsername(username);
        fileWriter(username, name, "DIGL", id, salt, password);
        Users.writeObjects();
    }
    
    /**
     * creates a new activity coordinator object, adds the object to the coordinator list, adds the details to the users file
     * @param name
     * @param id
     * @param username
     * @param salt
     * @param pass
     * @throws NoSuchAlgorithmException 
     */
    public static void createCoordinator(String name, String id, String username, String salt, String pass) throws NoSuchAlgorithmException, IOException{
        String password = Hasher.hash(pass+salt);
        ActivityCoordinator coordinator = new ActivityCoordinator(name, "Coordinator", id, username, salt, password);
        Users.addCoordinator(coordinator);
        Users.addUsername(username);
        Users.addId(id);
        fileWriter(username, name, "Coordinator", id, salt, password);
        Users.writeObjects();
    }

    /**
     * writes to the users file, writes all user details 
     * @param username
     * @param name
     * @param role
     * @param id
     * @param salt
     * @param password 
     */
    public static void fileWriter(String username, String name, String role, String id, String salt, String password){
        
        try {
            writer.write("\n" + "User:" + username);
            writer.write("\n" + "Name:" + name);
            writer.write("\n" + "Role:" + role);
            writer.write("\n" + "Id:" + id);
            writer.write("\n" + "Salt:" + salt);
            writer.write("\n" + "Pass:" + password);
            writer.write("\n");
            
        } catch (IOException ex) {
            System.getLogger(UserCreator.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
    
    /**
     * Makes an id for users and for activities
     * @param role
     * @return 
     */
    public static String idMaker(String role){
        String id = null;
        Random random = new Random();
        char[] array = new char[7];
        for(int i = 0; i < 7; i++){
            // generates a random from 1 to 36
            String rand = Integer.toString(random.nextInt(36) + 1);
            switch(rand){
                case "1":
                    array[i] = 'a';
                    break;
                case "2":
                    array[i] = 'b';
                    break;
                case "3":
                    array[i] = 'c';
                    break;
                case "4":
                    array[i] = 'd';
                    break;
                case "5":
                    array[i] = 'e';
                    break;
                case "6":
                    array[i] = 'f';
                    break;
                case "7":
                    array[i] = 'g';
                    break;
                case "8":
                    array[i] = 'h';
                    break;
                case "9":
                    array[i] = 'i';
                    break;
                case "10":
                    array[i] = 'j';
                    break;
                case "11":
                    array[i] = 'k';
                    break;
                case "12":
                    array[i] = 'l';
                    break;
                case "13":
                    array[i] = 'm';
                    break;
                case "14":
                    array[i] = 'n';
                    break;
                case "15":
                    array[i] = 'o';
                    break;
                case "16":
                    array[i] = 'p';
                    break;
                case "17":
                    array[i] = 'q';
                    break;
                case "18":
                    array[i] = 'r';
                    break;
                case "19":
                    array[i] = 's';
                    break;
                case "20":
                    array[i] = 't';
                    break;
                case "21":
                    array[i] = 'u';
                    break;
                case "22":
                    array[i] = 'v';
                    break;
                case "23":
                    array[i] = 'w';
                    break;
                case "24":
                    array[i] = 'x';
                    break;
                case "25":
                    array[i] = 'y';
                    break;
                case "26":
                    array[i] = 'z';
                    break;
                case "27":
                    array[i] = '0';
                    break;
                case "28":
                    array[i] = '1';
                    break;
                case "29":
                    array[i] = '2';
                    break;
                case "30":
                    array[i] = '3';
                    break;
                case "31":
                    array[i] = '4';
                    break;
                case "32":
                    array[i] = '5';
                    break;
                case "33":
                    array[i] = '6';
                    break;
                case "34":
                    array[i] = '7';
                    break;
                case "35":
                    array[i] = '8';
                    break;
                case "36":
                    array[i] = '9';
                    break;
            }
            String halfId = new String(array);
            switch(role){
                case "Senior":
                    id = "SM-" + halfId;
                    break;
                case "DIGM":
                    id = "DIGM-" + halfId;
                    break;
                case "DIGL":
                    id = "DIGL-" + halfId;
                    break;
                case "Coordinator":
                    id = "AC-" + halfId;
                    break;
                case "Member":
                    id = "M-" + halfId;
                    break;
                case "Activity":
                    id = "A-"+ halfId;
                    break;
            }
        }
        return id;
    }
    
    /**
     * closes the file writer
     */
    public static void closeWriter(){
        try {
            writer.close();
        } catch (IOException ex) {
            System.getLogger(UserCreator.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
}
