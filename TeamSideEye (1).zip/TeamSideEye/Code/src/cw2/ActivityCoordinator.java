/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class ActivityCoordinator extends Member implements Serializable{
    
    // an array of all open activities that the activity cooridinator has
    private ArrayList<Activity> openActivities = new ArrayList<Activity>();
    // an array of all cancelled activities 
    private ArrayList<Activity> cancelledActivities = new ArrayList<Activity>();
    
     
    
    /**
     * A constructor for the ActivityCoordinator class
     * @param x
     * @param y
     * @param z 
     * @param h
     */
    public ActivityCoordinator(String x, String y, String z, String h, String i, String j) {
        super(x, y, z, h, i, j);
    }
    
    /**
     * adds an activity to the activities array
     * @param x 
     */
    public void addActivity(Activity x){
        openActivities.add(x);
    }
    
    /**
     * creates a new activity and adds it to the activities array 
     * @param name
     * @param date
     * @param location
     * @param id 
     * @param recordType 
     */
    public void createActivity(String name, String date, String location, String id, String recordType){
        Activity activity = new Activity(name, date, location, id);
        addActivity(activity);
        activity.createRecord(recordType);
        Activities.addActivity(activity);
    }
    
    /**
     * cancels an activity and removes it from the openActivities array and adds it to the cancelled activities array
     * @param x 
     */
    public void cancelActivity(Activity x){
        String id = x.getId();
        x.cancelActivity();
        cancelledActivities.add(x);
        
        for(int i = 0; i < openActivities.size(); i++){
            if(openActivities.get(i).getId() == id){
                openActivities.remove(openActivities.get(i));
            }
        }
    }
    
    /**
     * returns the open activities array
     * @return 
     */
    public ArrayList<Activity> getOpenActivities(){
        return Activities.getAllOpenActivities();
    }

    /**
     * returns the cancelled activities array
     * @return 
     */
    public ArrayList<Activity> getCancelledActivities(){
        return cancelledActivities;
    }
}
