/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author George Hartley   UB: 25010763
 */
public class NewUserGUI implements ActionListener{
    
    // the frame for the gui
    private JFrame frame;
    // the panel which is on the frame
    private JPanel panel;
    // user label
    private JLabel label;
    // the text field for the username
    private JTextField userText;
    // the password field for the password
    private JPasswordField passText;
    // the second password field
    private JPasswordField passCheck;
    // text field for the name
    private JTextField nameText;
    // text field for the role
    private JTextField roleText;
    // button to submit new user
    private JButton submit;
    // the label that says the username is already taken
    private JLabel badUser;
    // the label that says invalid role
    private JLabel badRole;
    // label that says password don't match
    private JLabel badPass;
    
    /**
     * Constructor for the NewUserGUI class
     */
    public NewUserGUI(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(400,430);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Create New User");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        // adds the label above the text box asking for username
        label = new JLabel("Enter Username:");
        label.setBounds(10, 20 ,100, 25);
        panel.add(label);
        
        // adds the text box for the user to write username
        userText = new JTextField(20);
        userText.setBounds(10, 50, 200, 25);
        panel.add(userText);
        
        // adds the label above the text box asking for password
        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(10, 80, 80, 25);
        panel.add(passLabel);
        
        // adds the text box for the user to write password
        passText = new JPasswordField();
        passText.setBounds(10, 110, 200, 25);
        panel.add(passText);
        
        // adds the label above the text box asking to re-enter password
        JLabel checkLabel = new JLabel("Re-enter Password:");
        checkLabel.setBounds(10, 140, 120, 25);
        panel.add(checkLabel);
        
        // adds the text box for the user to re-enter password
        passCheck = new JPasswordField();
        passCheck.setBounds(10, 170, 200, 25);
        panel.add(passCheck);
        
        // adds the label for the name 
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(10, 200, 80, 25);
        panel.add(nameLabel);
        
        // adds the text field for the name
        nameText = new JTextField(20);
        nameText.setBounds(10, 230, 200, 25);
        panel.add(nameText);
        
        // adds the label for the role
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setBounds(10, 260, 80, 25);
        panel.add(roleLabel);
        
        // adds the text field for the name
        roleText = new JTextField(20);
        roleText.setBounds(10, 290, 200, 25);
        panel.add(roleText);
        
        // adds the button to submit the new user
        submit = new JButton("Submit");
        submit.setBounds(10, 335, 80, 25);
        submit.addActionListener(this);
        panel.add(submit);
        
        // warns the entered username already exists
        badUser = new JLabel("Username already exists");
        badUser.setBounds(120, 20, 200, 25);
        badUser.setForeground(Color.red);
        panel.add(badUser);
        badUser.setVisible(false);
        
        // warns that role was entered wrong
        badRole = new JLabel("Role must be Member, Senior, DIGM, DIGL, or Coordinator");
        badRole.setBounds(50, 260, 330, 25);
        badRole.setForeground(Color.red);
        panel.add(badRole);
        badRole.setVisible(false);
        
        // warns that the passwords do not match
        badPass = new JLabel("Passwords do not match");
        badPass.setBounds(80, 80, 150, 25);
        badPass.setForeground(Color.red);
        panel.add(badPass);
        badPass.setVisible(false);

        frame.setVisible(true);

    }
    
    
    /**
     * when the submit button is clicked, will check that the passwords match the username is unique and that the role is correct
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        boolean canProceed;
        String pass = passText.getText();
        String pass2 = passCheck.getText();
        String role = roleText.getText();
        String name = nameText.getText();
        String user = userText.getText();
        
        if(pass != pass2){
            canProceed = false;
            badPass.setVisible(true);
        }

        if(Users.isUniqueUser(user) == false){
            canProceed = false;
            badUser.setVisible(true);
        }
        
        if(Users.isCorrectRole(role) == false){
            canProceed = false;
            badRole.setVisible(true);
        }
        
        if(pass == pass2 && Users.isUniqueUser(user) == true && Users.isCorrectRole(role) == true){
            canProceed = true;
            badPass.setVisible(false);
            badUser.setVisible(false);
            badRole.setVisible(false);
        }

        if(canProceed = true){
            try {
                String salt = Hasher.saltMaker();
                String id = UserCreator.idMaker(role);
                while(Users.isUniqueId(id) == false){
                    id = UserCreator.idMaker(role);
                }
                try {
                    UserCreator creator = new UserCreator();
                } catch (IOException ex) {
                    System.getLogger(NewUserGUI.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
                }
                    
                switch(role){
                    case "Member":
                        UserCreator.createMember(name, id, user, salt, pass);
                        break;
                    case "Senior":
                        UserCreator.createSenior(name, id, user, salt, pass);
                        break;
                    case "DIGM":
                        UserCreator.createDIGM(name, id, user, salt, pass);
                        break;
                    case "DIGL":
                        UserCreator.createDIGL(name, id, user, salt, pass);
                        break;
                    case "Coordinator":
                        UserCreator.createCoordinator(name, id, user, salt, pass);
                        break;
                }
                Users.writeToFileWriter();
                
            } catch (NoSuchAlgorithmException ex) {
                System.getLogger(NewUserGUI.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            } catch (IOException ex) {
                System.getLogger(NewUserGUI.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            frame.dispose();
        }
    }
}
