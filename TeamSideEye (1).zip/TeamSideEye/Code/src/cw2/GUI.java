/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class GUI implements ActionListener{
    
    // the current screen currently open
    //public static String currentScreen;
    
    // the frame for the gui
    private JFrame frame;
    // the panel which is on the frame
    private JPanel panel;
    // user label
    private JLabel label;
    // the text field for the username
    private JTextField userText;
    // the password field for the password
    private JPasswordField passText;
    // text for when login is unsuccessful
    private JLabel unsuccessful;
    // a button for logging into the system
    private JButton login;
    // a button for creating a new user
    private JButton newUser;
    // a button used to display activity's record
    private JButton recordButton;
    // the activity currently displayed
    private Activity activityDisplayed;
    
    private JButton AiButton;
    
    /**
     * The GUI for the login screen for the system
     */
    public void loginScreen(){
        //currentScreen = "login";    // sets current screen to login screen
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,200);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Login");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        // adds the label above the text box asking for username
        label = new JLabel("Username:");
        label.setBounds(10, 20 ,80, 25);
        panel.add(label);
        
        // adds the text box for the user to write username
        userText = new JTextField(20);
        userText.setBounds(100, 20, 165, 25);
        panel.add(userText);
        
        // adds the label above the text box asking for password
        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(10, 50, 80, 25);
        panel.add(passLabel);
        
        // adds the text box for the user to write password
        passText = new JPasswordField();
        passText.setBounds(100, 50, 165, 25);
        panel.add(passText);
        
        login = new JButton("Login");
        login.setBounds(10, 80, 80, 25);
        login.addActionListener(this);
        panel.add(login);
        
        newUser = new JButton("New User");
        newUser.setBounds(10, 110, 100, 25);
        newUser.addActionListener(this);
        panel.add(newUser);
        
        // adds the label above the text box asking for password
        unsuccessful = new JLabel("Login Unsuccessful");
        unsuccessful.setBounds(100, 80, 125, 25);
        unsuccessful.setForeground(Color.red);
        panel.add(unsuccessful);
        unsuccessful.setVisible(false);
        
        frame.setVisible(true);
    }
    
    /**
     * a new window will appear displaying the relevant activities values
     * @param activity
     */
    public void displayActivity(Activity activity){
        activityDisplayed = activity;
        String name = activity.getName();
        String date = activity.getDate();
        String location = activity.getLocation();
        String id = activity.getId();
        String status = activity.getStatus();
        
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,320);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Login");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel nameLabel = new JLabel("Name: " + name);
        nameLabel.setBounds(10, 20, 150, 25);
        panel.add(nameLabel);
        
        JLabel dateLabel = new JLabel("Date: " + date);
        dateLabel.setBounds(10, 50, 150, 25);
        panel.add(dateLabel);
        
        JLabel locationLabel = new JLabel("Location: " + location);
        locationLabel.setBounds(10, 80, 250, 25);
        panel.add(locationLabel);
        
        JLabel idLabel = new JLabel("ID: " + id);
        idLabel.setBounds(10, 110, 100, 25);
        panel.add(idLabel);
        
        JLabel statusLabel = new JLabel("Status: " + status);
        statusLabel.setBounds(10, 140, 150, 25);
        panel.add(statusLabel);
        
        if(activity.getDIGL() != null){
            String DIGLName = activity.getDIGL().getName();
            JLabel DIGLLabel = new JLabel("DIGL: " + DIGLName);
            DIGLLabel.setBounds(10, 170, 150, 25);
            panel.add(DIGLLabel);
        }
        
        JLabel recordLabel = new JLabel("Click to display activity record");
        recordLabel.setBounds(10, 200, 250, 25);
        panel.add(recordLabel);
        
        recordButton = new JButton("Record");
        recordButton.setBounds(10, 230, 80, 25);
        recordButton.addActionListener(this);
        panel.add(recordButton);
        
        JButton updateButton = new JButton("Update");
        updateButton.setBounds(110, 230, 80, 25);
        updateButton.addActionListener(e -> {
            new CoordinatorGUI().updateActivity(activity);
        });
        panel.add(updateButton);
        
        frame.setVisible(true);
    }
    
    /**
     * display a window showing activity record data
     * @param record 
     */
    public void displayRecord(ActivityRecord record){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350, 320);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Activity Record");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel typeLabel = new JLabel("Type: " + record.getType());
        typeLabel.setBounds(10, 20, 150, 25);
        panel.add(typeLabel);
        
        JLabel idLabel = new JLabel("ID: " + record.getId());
        idLabel.setBounds(10, 50 , 150, 25);
        panel.add(idLabel);
        
        JLabel attendLabel = new JLabel("Attendance: " + Integer.toString(record.getAttendance()));
        attendLabel.setBounds(10, 80, 150, 25);
        panel.add(attendLabel);
        
        JLabel engageLabel = new JLabel("Crowd engagement: " + record.getEngagement().toLowerCase());
        engageLabel.setBounds(10, 110, 300, 25);
        panel.add(engageLabel);
        
        JLabel scrapLabel = new JLabel("Scrapped URL: " + record.getURL());
        scrapLabel.setBounds(10, 140, 300, 25);
        panel.add(scrapLabel);
        
        
        JTextArea labelText = new JTextArea(record.getLabel(), 3, 20);
        labelText.setBounds(10, 170, 250, 75);
        labelText.setEditable(false);
        panel.add(labelText);

        frame.setVisible(true);
    }
    
    /**
     * display the info of dig members in the group
     * @param digm 
     */
    public void displayDIGM(DIGM digm){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,280);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("Login");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        JLabel nameLabel = new JLabel("Name: "  + digm.getName());
        nameLabel.setBounds(10, 20 , 150, 25);
        panel.add(nameLabel);
        
        JLabel roleLabel = new JLabel("Role: "  + digm.getRole());
        roleLabel.setBounds(10, 50 , 150, 25);
        panel.add(roleLabel);
        
        JLabel idLabel = new JLabel("ID: "  + digm.getId());
        idLabel.setBounds(10, 80 , 150, 25);
        panel.add(idLabel);
        
        if(digm.getActivity() != null){
            JLabel activityLabel = new JLabel("Activity name: "  + digm.getActivity().getName());
            activityLabel.setBounds(10, 110 , 150, 25);
            panel.add(activityLabel);
            
            JLabel activityIdLabel = new JLabel("Activity ID: "  + digm.getActivity().getId());
            activityIdLabel.setBounds(10, 140 , 150, 25);
            panel.add(activityIdLabel);
        }
        frame.setVisible(true);
    }
    
    /**
     * GUI to create a new AI file
     */
    public void AiFileMaker(){
        //creates the panel
        panel = new JPanel();
        
        //creates the frame, sets frames size, name on frame
        frame = new JFrame();
        frame.setSize(350,280);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setTitle("ML Section");
        
        frame.add(panel);
        
        panel.setLayout(null);
        
        label = new JLabel("Enter file name. Include the file format");
        label.setBounds(10, 20, 250, 25);
        panel.add(label);
        
        userText = new JTextField(20);
        userText.setBounds(10, 50, 165, 25);
        panel.add(userText);
        
        AiButton = new JButton("Submit");
        AiButton.setBounds(10, 80, 80, 25);
        AiButton.addActionListener(this);
        panel.add(AiButton);
        
        frame.setVisible(true);
    }
    
    /**
     * When the login button is clicked, the username and password is taken, the relevant salt is added to the password
     * the password is hashed, and compared to the stored password. If equal the next screen is loaded.
     * 
     * When the new user button is clicked, the new user gui object is created
     * 
     * when the record button is clicked a record gui displaying record data is created
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == login) {
            String user = userText.getText();
            String pass = passText.getText();
            String hashed = null;
            String salt = Searcher.saltFinder(user);
            try {
                hashed = Hasher.hash(pass + salt);
            } catch (NoSuchAlgorithmException ex) {
                System.getLogger(GUI.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
                System.out.println("Password not hashed");
            }
            if (hashed.equals(Searcher.passFinder(user))) {
                User.setUser(Searcher.roleFinder(user), user);
                BD25System.currentUserType = Searcher.roleFinder(user);
                new HomeScreenGUI().setVisible(true);
                frame.dispose();
            } else {
                unsuccessful.setVisible(true);
            }
        }
        
        else if (e.getSource() == newUser){
            new NewUserGUI();
        }
        
        else if (e.getSource() == recordButton){
            displayRecord(activityDisplayed.getRecord());
        }
        
        else if(e.getSource() == AiButton){
            String name = userText.getText();
            AiFiles.createFile(name);
            frame.dispose();
        }
    }
    
    
    /**
     * Display the users name on the home screen
     * @return 
     */
    public static String displayName(){
        String name = null;
        switch(BD25System.currentUserType){
            case "Member":
                name = BD25System.userMember.getName();
                break;
            case "Senior":
               name = BD25System.userSenior.getName();
               break;
            case "DIGM":
                name = BD25System.userDIGM.getName();
                break;
            case "DIGL":
                name = BD25System.userDIGL.getName();
                break;
            case "Coordinator":
                name = BD25System.userCoordinator.getName();
                break;
        }
        return name;
    }
    
    /**
     * Display the users ID on the home screen
     * @return 
     */
    public static String displayId(){
        String id = null;
        switch(BD25System.currentUserType){
            case "Member":
                id = BD25System.userMember.getId();
                break;
            case "Senior":
               id = BD25System.userSenior.getId();
               break;
            case "DIGM":
                id = BD25System.userDIGM.getId();
                break;
            case "DIGL":
                id = BD25System.userDIGL.getId();
                break;
            case "Coordinator":
                id = BD25System.userCoordinator.getId();
                break;
        }
        return id;
    }
    
    /**
     * displays the DIGMs DIGL name
     * @return 
     */
    public static String displayDIGLName(){
        String name = BD25System.userDIGM.getLeader().getName();
        return name;
    }
    /**
     * Display the users role on the home screen
     * @return 
     */
    public static String displayRole(){
        String role = null;
        switch(BD25System.currentUserType){
            case "Member":
                role = BD25System.userMember.getRole();
                break;
            case "Senior":
               role = BD25System.userSenior.getRole();
               break;
            case "DIGM":
                role = BD25System.userDIGM.getRole();
                break;
            case "DIGL":
                role = BD25System.userDIGL.getRole();
                break;
            case "Coordinator":
                role = BD25System.userCoordinator.getRole();
                break;
        }
        return role;
    }
    
    /**
     * Displays the AI files on the jlist
     * @param x
     * @return 
     */
    public static JList displayAiFiles(JList x){
        ArrayList y = AiFiles.getFiles();
        ArrayList j = new ArrayList();
        for (int i = 0; i < y.size(); i++) {
            j.add(y.get(i));
        }
        DefaultListModel z = new DefaultListModel();
        z.addAll(j);
        x.setModel(z);
        return x;
    }
    
    /**
     * used to display and array list in home screen gui
     * tab can have values G (group)or A (activities)
     * int h is usually 1, its to determine list when multiple lists are on one tab
     * @param tab
     * @param x
     * @param h
     * @return 
     */
    public static JList displayArrayLists(char tab, JList x, int h){
        switch(BD25System.currentUserType){
            case "DIGM":
                if(tab == 'G' && BD25System.userDIGM.getLeader() != null && BD25System.userDIGM.getLeader().getGroup() != null){
                    ArrayList<DIGM> y = BD25System.userDIGM.getLeader().getGroup();
                    ArrayList j = new ArrayList();
                    for(int i = 0; i < y.size(); i++){
                        j.add(y.get(i).getName());
                    }
                    DefaultListModel z = new DefaultListModel();
                    z.addAll(j);
                    x.setModel(z);
                }
                else if(tab == 'A' && BD25System.userDIGM.getActivity() != null){
                    Activity y = BD25System.userDIGM.getActivity();
                    String j = y.getName();
                    DefaultListModel z = new DefaultListModel();
                    z.addElement(j);
                    x.setModel(z);
                }
                break;
            case "DIGL":
                if(tab == 'G' && BD25System.userDIGL.getGroup() != null){
                    ArrayList<DIGM> y = BD25System.userDIGL.getGroup();
                    ArrayList j = new ArrayList();
                    for(int i = 0; i < y.size(); i++){
                        j.add(y.get(i).getName());
                    }
                    DefaultListModel z = new DefaultListModel();
                    z.addAll(j);
                    x.setModel(z);
                }
                else if(tab == 'A' && BD25System.userDIGL.getActivity() != null){
                    Activity y = BD25System.userDIGL.getActivity();
                    String j = y.getName();
                    DefaultListModel z = new DefaultListModel();
                    z.addElement(j);
                    x.setModel(z);
                }
                break;
            case "Coordinator":
                if(tab == 'A' && h == 1 && BD25System.userCoordinator.getOpenActivities() != null){
                    ArrayList<Activity> y = BD25System.userCoordinator.getOpenActivities();
                    ArrayList j = new ArrayList();
                    for(int i = 0; i < y.size(); i++){
                        j.add(y.get(i).getName());
                    }
                    DefaultListModel z = new DefaultListModel();
                    z.addAll(j);
                    x.setModel(z);
                }
                else if(tab == 'A' && h == 2 && BD25System.userCoordinator.getCancelledActivities() != null){
                    ArrayList<Activity> y = BD25System.userCoordinator.getCancelledActivities();
                    ArrayList j = new ArrayList();
                    for(int i = 0; i < y.size(); i++){
                        j.add(y.get(i).getName());
                    }
                    DefaultListModel z = new DefaultListModel();
                    z.addAll(j);
                    x.setModel(z);
                }
                break;
        }
        return x;
    }
    
    /**
     * gets the open activities to display on jlist 
     * @param x
     * @return 
     */
    public static JList<Activity> getActivity(JList<Activity> x){
        ArrayList y = BD25System.userCoordinator.getOpenActivities();
        DefaultListModel z = new DefaultListModel();
        z.addElement(y);
        x.setModel(z);
        return x;
    }

    /**
     * gets the DIGM group to display on jlist
     * @param x
     * @return 
     */
    public static JList<DIGM> getGroup(JList<DIGM> x){
        ArrayList y = BD25System.userDIGM.getLeader().getGroup();
        DefaultListModel z = new DefaultListModel();
        z.addElement(y);
        x.setModel(z);
        return x;
    }
}
