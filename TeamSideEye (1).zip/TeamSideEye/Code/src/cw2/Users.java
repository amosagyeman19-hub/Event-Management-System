/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cw2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author George Hartley   UB:25010763
 */
public class Users implements Serializable{
    
    // an array containng all members
    private static ArrayList<Member> members;
    // an array containng all senior members
    private static ArrayList<SeniorMember> seniors;
    // an array containng all DIGMs
    public static ArrayList<DIGM> digms;
    // an array containng all DIGLs
    private static ArrayList<DIGL> digls;
    // an array containng all DIGMs
    private static ArrayList<ActivityCoordinator> coordinators;
    // an array of all current usernames, usernames must be unique
    private static ArrayList<String> usernames;
    // an array of all ids user and activity
    private static ArrayList<String> ids;
    // an array of all valid roles
    private static String[] roles = {"DIGM", "DIGL", "Member", "Coordinator", "Senior"};
    
    /**
     * adds a member to the members array
     * @param x 
     */
    public static void addMember(Member x){
        members.add(x);
    }
    
    /**
     * adds a senior member to the seniors array
     * @param x 
     */
    public static void addSenior(SeniorMember x){
        seniors.add(x);
    }
    
    /**
     * adds a DIGM to the digms array
     * @param x 
     */
    public static void addDIGM(DIGM x){
        digms.add(x);
    }
    
    /**
     * adds a DIGL to the digls array
     * @param x 
     */
    public static void addDIGL(DIGL x){
        digls.add(x);
    }
    
    /**
     * adds a activity coordinator to the coordinators array
     * @param x 
     */
    public static void addCoordinator(ActivityCoordinator x){
        coordinators.add(x);
    }
    
    /**
     * adds a username to the usernames array 
     * @param x 
     */
    public static void addUsername(String x){
        usernames.add(x);
    }
    
    /**
     * adds the id to the ids array
     * @param x 
     */
    public static void addId(String x){
        ids.add(x);
    }
    
    /**
     * finds the needed member in the member array
     * @param username
     * @return 
     */
    public static Member findMember(String username) {
        Member objectToSend = null;
        for (int i = 0; i < members.size(); i++) {
            if (members.get(i).getUsername().equals(username)) {
                objectToSend = members.get(i);
            }
        }
        return objectToSend;
    }
    
    /**
     * finds the needed senior member in the senior array
     * @param username
     * @return 
     */
    public static SeniorMember findSenior(String username) {
        SeniorMember objectToSend = null;
        for (int i = 0; i < seniors.size(); i++) {
            if (seniors.get(i).getUsername().equals(username)) {
                objectToSend = seniors.get(i);
            }
        }
        return objectToSend;
    }
    
    /**
     * finds the needed DIGM in the digms array
     * @param username
     * @return 
     */
    public static DIGM findDIGM(String username) {
        DIGM objectToSend = null;
        for (int i = 0; i < digms.size(); i++) {
            if (digms.get(i).getUsername().equals(username)) {
                objectToSend = digms.get(i);
            }
        }
        return objectToSend;
    }
    
    /**
     * finds the needed DIGL in the digls array
     * @param username
     * @return 
     */
    public static DIGL findDIGL(String username) {
        DIGL objectToSend = null;
        for (int i = 0; i < digls.size(); i++) {
            if (digls.get(i).getUsername().equals(username)) {
                objectToSend = digls.get(i);
            }
        }
        return objectToSend;
    }
    
    /**
     * finds the needed DIGM in the digms array from their name
     * @param name
     * @return 
     */
    public static DIGM findDIGMFromName(String name) {
        DIGM objectToSend = null;
        for (int i = 0; i < digms.size(); i++) {
            if (digms.get(i).getName().equals(name)) {
                objectToSend = digms.get(i);
            }
        }
        return objectToSend;
    }
    
    /**
     * finds the needed Activity Coordinator in the coordinators array
     * @param username
     * @return 
     */
    public static ActivityCoordinator findCoordinator(String username) {
        ActivityCoordinator objectToSend = null;
        for (int i = 0; i < coordinators.size(); i++) {
            if (coordinators.get(i).getUsername().equals(username)) {
                objectToSend = coordinators.get(i);
            }
        }
        return objectToSend;
    }
    
    /**
     * find out if a username is unique, returns true if it is unique, false if not
     * @param user
     * @return 
     */
    public static boolean isUniqueUser(String user){
        boolean isUnique = true;
        for(int i = 0; i < usernames.size(); i++){
            if(usernames.get(i).equals(user)){
                isUnique = false;
            }
        }
        return isUnique;
    }
    
    /**
     * finds out if the entered role is valid
     * @param role
     * @return 
     */
    public static boolean isCorrectRole(String role){
        boolean isCorrect = false;
        for(int i = 0; i < roles.length; i++){
            if(roles[i].equals(role)){
                isCorrect = true;
            }
        }
        return isCorrect;
    }
    
    /**
     * find of if the entered id already exists
     * @param id
     * @return 
     */
    public static boolean isUniqueId(String id){
        boolean isUnique = true;
        for(int i = 0; i < ids.size(); i++){
            if(ids.get(i).equals(id)){
                isUnique = false;
            }
        }
        return isUnique;
    }
    
    /**
     * returns the DIGM with the entered id
     * @return 
     */
    public static DIGM DIGMFindId(String id){
        DIGM returnDIGM = null;
        for(int i = 0; i < digms.size(); i++){
            if(digms.get(i).getId().equals(id)){
                returnDIGM = digms.get(i);
            }
        }
        return returnDIGM;
    }
    
    /**
     * write objects into ser files for use as save files
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public static void writeObjects() throws FileNotFoundException, IOException{
        FileOutputStream fileOut1 = new FileOutputStream("DIGMs.ser");
        ObjectOutputStream out1 = new ObjectOutputStream(fileOut1);
        
        FileOutputStream fileOut2 = new FileOutputStream("DIGLs.ser");
        ObjectOutputStream out2 = new ObjectOutputStream(fileOut2);
        
        FileOutputStream fileOut3 = new FileOutputStream("Coordinators.ser");
        ObjectOutputStream out3 = new ObjectOutputStream(fileOut3);
        
        FileOutputStream fileOut4 = new FileOutputStream("Members.ser");
        ObjectOutputStream out4 = new ObjectOutputStream(fileOut4);
        
        FileOutputStream fileOut5 = new FileOutputStream("Seniors.ser");
        ObjectOutputStream out5 = new ObjectOutputStream(fileOut5);
        
        FileOutputStream fileOut6 = new FileOutputStream("Usernames.ser");
        ObjectOutputStream out6 = new ObjectOutputStream(fileOut6);
        
        FileOutputStream fileOut7 = new FileOutputStream("IDs.ser");
        ObjectOutputStream out7 = new ObjectOutputStream(fileOut7);
        
        out1.writeObject(digms);
        out2.writeObject(digls);
        out3.writeObject(coordinators);
        out4.writeObject(members);
        out5.writeObject(seniors);
        out6.writeObject(usernames);
        out7.writeObject(ids);
        
        out1.close();
        out2.close();
        out3.close();
        out4.close();
        out5.close();
        out6.close();
        out7.close();
    }
    
    /**
     * reads the ser files as save files for user objects
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public static void readObjects() throws IOException, ClassNotFoundException{
        FileInputStream fileIn1 = new FileInputStream("DIGMs.ser");
        ObjectInputStream in1 = new ObjectInputStream(fileIn1);
        
        FileInputStream fileIn2 = new FileInputStream("DIGLs.ser");
        ObjectInputStream in2 = new ObjectInputStream(fileIn2);
        
        FileInputStream fileIn3 = new FileInputStream("Coordinators.ser");
        ObjectInputStream in3 = new ObjectInputStream(fileIn3);
        
        FileInputStream fileIn4 = new FileInputStream("Members.ser");
        ObjectInputStream in4 = new ObjectInputStream(fileIn4);
        
        FileInputStream fileIn5 = new FileInputStream("Seniors.ser");
        ObjectInputStream in5 = new ObjectInputStream(fileIn5);
        
        FileInputStream fileIn6 = new FileInputStream("Usernames.ser");
        ObjectInputStream in6 = new ObjectInputStream(fileIn6);
        
        FileInputStream fileIn7 = new FileInputStream("IDs.ser");
        ObjectInputStream in7 = new ObjectInputStream(fileIn7);
        
        digms = (ArrayList<DIGM>) in1.readObject();
        digls = (ArrayList<DIGL>) in2.readObject();
        coordinators = (ArrayList<ActivityCoordinator>) in3.readObject();
        members = (ArrayList<Member>) in4.readObject();
        seniors = (ArrayList<SeniorMember>) in5.readObject();
        usernames = (ArrayList<String>) in6.readObject();
        ids = (ArrayList<String>) in7.readObject();
        
        in1.close();
        in2.close();
        in3.close();
        in4.close();
        in5.close();
        in6.close();
        in7.close();
        
        for(int i = 0; i < digms.size(); i++){
            if(digms.get(i).getActivity() != null){
                Activities.addActivity(digms.get(i).getActivity());
            }
        }
        for(int i = 0; i < digls.size(); i++){
            if(digls.get(i).getActivity() != null){
                Activities.addActivity(digls.get(i).getActivity());
            }
        }
        for(int i = 0; i < coordinators.size(); i++){
            if(coordinators.get(i).getOpenActivities() != null){
                ArrayList<Activity> r = coordinators.get(i).getOpenActivities();
                for(int j = 0; j < coordinators.get(i).getOpenActivities().size(); j++){
                    Activities.addActivity(r.get(j));
                }
            }
            if(coordinators.get(i).getCancelledActivities() != null){
                ArrayList<Activity> r = coordinators.get(i).getCancelledActivities();
                for(int j = 0; j < coordinators.get(i).getCancelledActivities().size(); j++){
                    Activities.addActivity(r.get(j));
                }
            }
        }
    }
    
    /**
     * writes user data into the users file
     * @throws IOException 
     */
    public static void writeToFileWriter() throws IOException{
        new UserCreator();
        for(int i = 0; i < digms.size(); i++){
            String username = digms.get(i).getUsername();
            String name = digms.get(i).getName();
            String role = "DIGM";
            String id = digms.get(i).getId();
            String salt = digms.get(i).getSalt();
            String password = digms.get(i).getPass();
            UserCreator.fileWriter(username,name,role,id,salt,password);
        }
        for(int i = 0; i < digls.size(); i++){
            String username = digls.get(i).getUsername();
            String name = digls.get(i).getName();
            String role = "DIGL";
            String id = digls.get(i).getId();
            String salt = digls.get(i).getSalt();
            String password = digls.get(i).getPass();
            UserCreator.fileWriter(username,name,role,id,salt,password);
        }
        for(int i = 0; i < coordinators.size(); i++){
            String username = coordinators.get(i).getUsername();
            String name = coordinators.get(i).getName();
            String role = "Coordinator";
            String id = coordinators.get(i).getId();
            String salt = coordinators.get(i).getSalt();
            String password = coordinators.get(i).getPass();
            UserCreator.fileWriter(username,name,role,id,salt,password);
        }
        for(int i = 0; i < members.size(); i++){
            String username = members.get(i).getUsername();
            String name = members.get(i).getName();
            String role = "Member";
            String id = members.get(i).getId();
            String salt = members.get(i).getSalt();
            String password = members.get(i).getPass();
            UserCreator.fileWriter(username,name,role,id,salt,password);
        }
        for(int i = 0; i < seniors.size(); i++){
            String username = seniors.get(i).getUsername();
            String name = seniors.get(i).getName();
            String role = "Senior";
            String id = seniors.get(i).getId();
            String salt = seniors.get(i).getSalt();
            String password = seniors.get(i).getPass();
            UserCreator.fileWriter(username,name,role,id,salt,password);
        }
        UserCreator.closeWriter();
    }
}
